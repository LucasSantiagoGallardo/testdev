
"use client";

import DefaultLayout from "@/components/Layouts/DefaultLaout";


import Dashboard from "@/components/user/userDashboard";

const Profile = () => {
  return (
    <DefaultLayout>
      <div className="mx-auto w-full max-w-[970px]">




      </div>
     
<Dashboard></Dashboard>

      
    </DefaultLayout>
  );
};

export default Profile;
