import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import Swal from 'sweetalert2';

const UserMenuSelection = () => {
  const [events, setEvents] = useState([]);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const storedDni = localStorage.getItem("dni");
    if (storedDni) {
      setUserId(storedDni);
      console.log("DNI encontrado en localStorage:", storedDni);
    } else {
      console.error("DNI no encontrado en localStorage");
    }
  }, []);

  useEffect(() => {
    // Cargar todos los menús disponibles
    fetch('/api/fetch_all_menus.php')
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          const loadedEvents = data.menus.map((menu) => ({
            title: `${menu.tipo}: ${menu.nombre}`,
            start: menu.fecha,
            backgroundColor: menuColors[menu.tipo] || 'gray',
            extendedProps: {
              tipo: menu.tipo,
              nombre: menu.nombre,
            },
          }));
          setEvents(loadedEvents);
        }
      });

    // Cargar las elecciones del usuario
    if (userId) {
      fetch('/api/fetch_user_selections.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            const userSelections = data.selections.map((selection) => ({
              title: `Tu elección: ${selection.opcion_menu}`,
              start: selection.fecha,
              backgroundColor: 'red', // Color para destacar la elección
              borderColor: 'black',
              textColor: 'white',
              extendedProps: {
                tipo: selection.opcion_menu,
                seleccionada: true,
              },
            }));
            setEvents((prevEvents) => [...prevEvents, ...userSelections]);
          }
        });
    }
  }, [userId]);

  const handleEventClick = (eventClickInfo) => {
    const { tipo, nombre, seleccionada } = eventClickInfo.event.extendedProps;
    const fechaSeleccionada = eventClickInfo.event.startStr;

    if (seleccionada) {
      Swal.fire('Elección ya registrada', `Ya has seleccionado: ${nombre} para este día.`, 'info');
      return;
    }

    // Verificar si ya hay una selección para la fecha
    fetch('/api/verificar_eleccion.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fecha: fechaSeleccionada,
        user_id: userId,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.eleccion_existente) {
          Swal.fire('Elección ya registrada', 'Ya has seleccionado una opción para este día.', 'info');
        } else {
          Swal.fire({
            title: `Seleccionar Menú para ${fechaSeleccionada}`,
            text: `Opción seleccionada: ${tipo} - ${nombre}`,
            showCancelButton: true,
            confirmButtonText: 'Confirmar',
            confirmButtonColor: 'green',
            cancelButtonColor:'red',
          }).then((result) => {
            if (result.isConfirmed && userId) {
              fetch('/api/guardar_eleccion.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  fecha: fechaSeleccionada,
                  user_id: userId,
                  opcion_menu: tipo,
                }),
              })
                .then((response) => response.json())
                .then((data) => {
                  if (data.success) {
                    Swal.fire('Elección guardada', 'Tu elección ha sido registrada.', 'success');
                    setEvents((prevEvents) => [
                      ...prevEvents,
                      {
                        title: `Tu elección: ${nombre}`,
                        start: fechaSeleccionada,
                        backgroundColor: 'red',
                        borderColor: 'black',
                        textColor: 'white',
                        extendedProps: {
                          tipo,
                          seleccionada: true,
                        },
                      },
                    ]);
                  } else {
                    Swal.fire('Error', data.message || 'Error al guardar la elección.', 'error');
                  }
                })
                .catch((error) => {
                  console.error("Error al guardar la elección:", error);
                  Swal.fire('Error', 'Hubo un problema al procesar tu solicitud.', 'error');
                });
            }
          });
        }
      })
      .catch((error) => {
        console.error("Error al verificar la elección:", error);
        Swal.fire('Error', 'Hubo un problema al verificar tu elección.', 'error');
      });
  };

  const menuColors = {
    plato_principal: 'blue',
    menu_vegetariano: 'green',
    ensalada: 'purple',
    postre: 'orange',
  };

  return (
    <div>
      <h1>Selecciona tu menú para el día</h1>
      <FullCalendar
        plugins={[dayGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        events={events}
        eventClick={handleEventClick}
      />
    </div>
  );
};

export default UserMenuSelection;